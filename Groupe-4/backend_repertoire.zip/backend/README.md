# Back end – Répertoire téléphonique (API REST)

Projet 4 – ICT University – Soumelong Jordan Landry (ICTU20251294)

API FastAPI qui reprend la logique du programme console (`gestion_contacts.py`) :
ajout, modification, suppression, recherche, affichage trié, statistiques.
Les données sont stockées dans `contacts.json`.

## Installation

```bash
cd backend
python -m venv .venv
.venv\Scripts\activate          # Windows   (Linux/macOS : source .venv/bin/activate)
pip install -r requirements.txt
```

## Lancement

```bash
uvicorn app.main:app --reload
```

Documentation interactive : http://127.0.0.1:8000/docs

## Endpoints

| Méthode | Route | Rôle |
| --- | --- | --- |
| GET | `/contacts` | Liste complète (triée par nom) |
| POST | `/contacts` | Ajouter un contact |
| GET | `/contacts/{id}` | Détail d'un contact |
| PUT | `/contacts/{id}` | Modifier (champs partiels) |
| DELETE | `/contacts/{id}` | Supprimer |
| GET | `/contacts/search?nom=...&numero=...` | Recherche partielle |
| GET | `/contacts/stats` | Statistiques |

Exemple :

```bash
curl -X POST http://127.0.0.1:8000/contacts \
  -H "Content-Type: application/json" \
  -d '{"nom":"Alexandre Békonje","numero":"699112233","email":"alexandre@example.com"}'
```

## Tests

```bash
pytest
```

## Structure

```
backend/
├── app/
│   ├── main.py        # routes de l'API
│   ├── services.py    # logique métier
│   ├── storage.py     # lecture/écriture JSON
│   └── schemas.py     # validation des données
├── tests/test_api.py
└── requirements.txt
```

Variable optionnelle : `CONTACTS_FILE` pour changer l'emplacement du fichier JSON.
