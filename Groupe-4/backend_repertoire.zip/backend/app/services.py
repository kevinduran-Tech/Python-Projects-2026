"""Logique métier du répertoire (sans aucun input/print)."""
import uuid
from typing import Optional

from . import storage


class ContactIntrouvable(Exception):
    pass


class NumeroDejaUtilise(Exception):
    pass


def numero_existe(repertoire: list[dict], numero: str, ignorer_id: Optional[str] = None) -> bool:
    for contact in repertoire:
        if contact["numero"] == numero and contact["id"] != ignorer_id:
            return True
    return False


def lister(tri_inverse: bool = False) -> list[dict]:
    """Tous les contacts, triés par ordre alphabétique du nom."""
    return sorted(storage.charger_contacts(), key=lambda c: c["nom"].lower(), reverse=tri_inverse)


def obtenir(contact_id: str) -> dict:
    for contact in storage.charger_contacts():
        if contact["id"] == contact_id:
            return contact
    raise ContactIntrouvable(contact_id)


def ajouter(nom: str, numero: str, email: Optional[str]) -> dict:
    repertoire = storage.charger_contacts()
    if numero_existe(repertoire, numero):
        raise NumeroDejaUtilise(numero)
    contact = {"id": uuid.uuid4().hex, "nom": nom, "numero": numero, "email": email}
    repertoire.append(contact)
    storage.sauvegarder_contacts(repertoire)
    return contact


def modifier(contact_id: str, changements: dict) -> dict:
    repertoire = storage.charger_contacts()
    for contact in repertoire:
        if contact["id"] == contact_id:
            nouveau_numero = changements.get("numero")
            if nouveau_numero and numero_existe(repertoire, nouveau_numero, ignorer_id=contact_id):
                raise NumeroDejaUtilise(nouveau_numero)
            for cle, valeur in changements.items():
                if cle == "email" or valeur is not None:
                    contact[cle] = valeur
            storage.sauvegarder_contacts(repertoire)
            return contact
    raise ContactIntrouvable(contact_id)


def supprimer(contact_id: str) -> None:
    repertoire = storage.charger_contacts()
    restants = [c for c in repertoire if c["id"] != contact_id]
    if len(restants) == len(repertoire):
        raise ContactIntrouvable(contact_id)
    storage.sauvegarder_contacts(restants)


def rechercher(nom: Optional[str] = None, numero: Optional[str] = None) -> list[dict]:
    """Recherche partielle par nom (insensible à la casse) et/ou par numéro."""
    resultats = []
    for contact in storage.charger_contacts():
        if nom and nom.strip().lower() not in contact["nom"].lower():
            continue
        if numero and numero.strip() not in contact["numero"]:
            continue
        resultats.append(contact)
    return sorted(resultats, key=lambda c: c["nom"].lower())


def statistiques() -> dict:
    repertoire = storage.charger_contacts()
    total = len(repertoire)
    avec_email = sum(1 for c in repertoire if c.get("email"))
    lettres: dict[str, int] = {}
    for c in repertoire:
        lettre = c["nom"][0].upper()
        lettres[lettre] = lettres.get(lettre, 0) + 1
    lettre = max(lettres, key=lettres.get) if lettres else None
    return {
        "total": total,
        "avec_email": avec_email,
        "sans_email": total - avec_email,
        "lettre_frequente": lettre,
        "occurrences_lettre": lettres.get(lettre, 0) if lettre else 0,
    }
