"""Schémas de validation des données (entrées / sorties de l'API)."""
from typing import Optional

from pydantic import BaseModel, Field, field_validator


def _nettoyer(valeur: Optional[str]) -> Optional[str]:
    if valeur is None:
        return None
    valeur = valeur.strip()
    return valeur or None


class ContactCreate(BaseModel):
    nom: str = Field(..., min_length=1, max_length=100)
    numero: str = Field(..., min_length=1, max_length=20)
    email: Optional[str] = Field(default=None, max_length=150)

    @field_validator("nom", "numero")
    @classmethod
    def non_vide(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Ce champ ne peut pas être vide.")
        return v

    @field_validator("email")
    @classmethod
    def email_valide(cls, v: Optional[str]) -> Optional[str]:
        v = _nettoyer(v)
        if v is not None and ("@" not in v or v.startswith("@") or v.endswith("@")):
            raise ValueError("Adresse électronique invalide.")
        return v


class ContactUpdate(BaseModel):
    """Tous les champs sont facultatifs : seuls ceux fournis sont modifiés."""
    nom: Optional[str] = Field(default=None, max_length=100)
    numero: Optional[str] = Field(default=None, max_length=20)
    email: Optional[str] = Field(default=None, max_length=150)

    @field_validator("nom", "numero")
    @classmethod
    def non_vide(cls, v: Optional[str]) -> Optional[str]:
        if v is None:
            return v
        v = v.strip()
        if not v:
            raise ValueError("Ce champ ne peut pas être vide.")
        return v

    @field_validator("email")
    @classmethod
    def email_valide(cls, v: Optional[str]) -> Optional[str]:
        v = _nettoyer(v)
        if v is not None and ("@" not in v or v.startswith("@") or v.endswith("@")):
            raise ValueError("Adresse électronique invalide.")
        return v


class Contact(BaseModel):
    id: str
    nom: str
    numero: str
    email: Optional[str] = None


class Statistiques(BaseModel):
    total: int
    avec_email: int
    sans_email: int
    lettre_frequente: Optional[str] = None
    occurrences_lettre: int = 0
