"""Persistance JSON (équivalent de charger/sauvegarder_contacts du programme console)."""
import json
import os
import uuid
from pathlib import Path
from threading import Lock

# Chemin configurable via la variable d'environnement CONTACTS_FILE
FICHIER_DONNEES = Path(os.getenv("CONTACTS_FILE", "contacts.json"))
_verrou = Lock()


def charger_contacts() -> list[dict]:
    """Charge la liste des contacts ; liste vide si le fichier est absent ou corrompu.
    Les anciens contacts (sans id) reçoivent un identifiant automatiquement."""
    if not FICHIER_DONNEES.exists():
        return []
    try:
        with open(FICHIER_DONNEES, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []
    if not isinstance(data, list):
        return []
    for contact in data:
        contact.setdefault("id", uuid.uuid4().hex)
        contact.setdefault("email", None)
    return data


def sauvegarder_contacts(repertoire: list[dict]) -> None:
    """Écrit le répertoire dans le fichier JSON (écriture atomique)."""
    with _verrou:
        tmp = FICHIER_DONNEES.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(repertoire, f, ensure_ascii=False, indent=4)
        os.replace(tmp, FICHIER_DONNEES)
