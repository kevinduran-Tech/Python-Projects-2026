"""API REST du répertoire téléphonique.

Lancer :  uvicorn app.main:app --reload
Docs interactives : http://127.0.0.1:8000/docs
"""
from typing import Optional

from fastapi import FastAPI, HTTPException, Query, Response, status
from fastapi.middleware.cors import CORSMiddleware

from . import services
from .schemas import Contact, ContactCreate, ContactUpdate, Statistiques

app = FastAPI(
    title="Répertoire téléphonique - API",
    description="Projet 4 - ICT University - Soumelong Jordan Landry (ICTU20251294)",
    version="1.0.0",
)

# Autorise un futur front end (React, HTML/JS...) à appeler l'API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/", tags=["Général"])
def accueil():
    return {"message": "API du répertoire téléphonique", "docs": "/docs"}


@app.get("/contacts", response_model=list[Contact], tags=["Contacts"])
def lister_contacts():
    """Affiche tous les contacts, triés par nom."""
    return services.lister()


# NB : les routes fixes (/search, /stats) doivent précéder /contacts/{id}
@app.get("/contacts/search", response_model=list[Contact], tags=["Contacts"])
def rechercher_contacts(
    nom: Optional[str] = Query(None, description="Nom ou partie du nom"),
    numero: Optional[str] = Query(None, description="Numéro ou partie du numéro"),
):
    """Recherche par nom et/ou par numéro."""
    if not nom and not numero:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Fournir 'nom' ou 'numero'.")
    return services.rechercher(nom, numero)


@app.get("/contacts/stats", response_model=Statistiques, tags=["Contacts"])
def statistiques():
    """Nombre total, emails renseignés, lettre initiale la plus fréquente."""
    return services.statistiques()


@app.get("/contacts/{contact_id}", response_model=Contact, tags=["Contacts"])
def obtenir_contact(contact_id: str):
    try:
        return services.obtenir(contact_id)
    except services.ContactIntrouvable:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Contact introuvable.")


@app.post("/contacts", response_model=Contact, status_code=status.HTTP_201_CREATED, tags=["Contacts"])
def ajouter_contact(contact: ContactCreate):
    try:
        return services.ajouter(contact.nom, contact.numero, contact.email)
    except services.NumeroDejaUtilise:
        raise HTTPException(status.HTTP_409_CONFLICT, "Ce numéro est déjà utilisé par un autre contact.")


@app.put("/contacts/{contact_id}", response_model=Contact, tags=["Contacts"])
def modifier_contact(contact_id: str, changements: ContactUpdate):
    try:
        return services.modifier(contact_id, changements.model_dump(exclude_unset=True))
    except services.ContactIntrouvable:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Contact introuvable.")
    except services.NumeroDejaUtilise:
        raise HTTPException(status.HTTP_409_CONFLICT, "Ce numéro est déjà utilisé par un autre contact.")


@app.delete("/contacts/{contact_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Contacts"])
def supprimer_contact(contact_id: str):
    try:
        services.supprimer(contact_id)
    except services.ContactIntrouvable:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Contact introuvable.")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
