import pytest
from fastapi.testclient import TestClient

from app import storage
from app.main import app


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(storage, "FICHIER_DONNEES", tmp_path / "contacts.json")
    return TestClient(app)


def creer(client, nom="Alexandre Békonje", numero="699112233", email="alexandre@example.com"):
    return client.post("/contacts", json={"nom": nom, "numero": numero, "email": email})


def test_ajout_et_liste(client):
    r = creer(client)
    assert r.status_code == 201
    assert client.get("/contacts").json()[0]["nom"] == "Alexandre Békonje"


def test_liste_triee(client):
    creer(client, "Zoé", "1")
    creer(client, "Alice", "2")
    assert [c["nom"] for c in client.get("/contacts").json()] == ["Alice", "Zoé"]


def test_doublon_numero(client):
    creer(client)
    assert creer(client, nom="Autre").status_code == 409


def test_validation(client):
    assert client.post("/contacts", json={"nom": " ", "numero": "1"}).status_code == 422
    assert creer(client, email="pas-un-email").status_code == 422


def test_recherche(client):
    creer(client, "Alexandre", "699112233")
    creer(client, "Brice", "677445566")
    assert len(client.get("/contacts/search", params={"nom": "alex"}).json()) == 1
    assert len(client.get("/contacts/search", params={"numero": "6774"}).json()) == 1
    assert client.get("/contacts/search").status_code == 400


def test_modification(client):
    cid = creer(client).json()["id"]
    r = client.put(f"/contacts/{cid}", json={"nom": "Alex B."})
    assert r.status_code == 200 and r.json()["nom"] == "Alex B."
    assert r.json()["numero"] == "699112233"
    r = client.put(f"/contacts/{cid}", json={"email": None})
    assert r.json()["email"] is None


def test_modification_numero_doublon(client):
    creer(client, "A", "1")
    cid = creer(client, "B", "2").json()["id"]
    assert client.put(f"/contacts/{cid}", json={"numero": "1"}).status_code == 409


def test_suppression(client):
    cid = creer(client).json()["id"]
    assert client.delete(f"/contacts/{cid}").status_code == 204
    assert client.get(f"/contacts/{cid}").status_code == 404
    assert client.delete(f"/contacts/{cid}").status_code == 404


def test_statistiques(client):
    creer(client, "Alice", "1", "a@x.com")
    creer(client, "Adam", "2", None)
    creer(client, "Bob", "3", None)
    s = client.get("/contacts/stats").json()
    assert s == {"total": 3, "avec_email": 1, "sans_email": 2,
                 "lettre_frequente": "A", "occurrences_lettre": 2}
